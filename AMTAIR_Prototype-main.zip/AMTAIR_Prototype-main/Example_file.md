# Unconnected titles with descriptions

<a>: I am currently in no relation.

<b>: It's complicated.

<c>: I feel disconnected.

# Two generation connected arguments

[Thesis]: Censorship is not wrong in principle.
  + <P1a>: Freedom of speech is never an absolute right but an aspiration. It ceases to be a right when it causes harm to others. Therefore it is not the case that censorship is wrong in principle. #pro
  + <P1b>: We all recognise the value of, for example, legislating against incitement to racial hatred. #pro
   - <C1b>: Censorship such as legislation against incitement to racial hatred drives racists and others underground and thus entrenches and ghettoises that section of the community rather than drawing its members into open and rational debate. #con
  + <P2>: Certain types of literature or visual image have been conclusively linked to crime. Excessive sex and violence in film and television has been shown (especially in studies in the US) to contribute to a tendency towards similar behaviour in spectators. There is no excuse for this and such images must be sacrificed, no matter what their artistic merit. #pro
   - <C2>: In fact, the link between sex and violence on screen and in real life is far from conclusive. To look at it from another angle, those individuals who _already have tendencies_ to violence are likely to watch violent `video nasties', just as those with a predilection for rape are likely to use pornography. The two are therefore connected but the individual's personality is formed first. #con
    - <C3>: Trying whether a third generation will also work. /* plus adding a comment to ignore <hallo> */
  - <C1a>: Censorship is wrong in principle. However violently we may disagree with a person's point of view or mode of expression, they must be free to express themselves in a free and civilized society.



