# AMTAIR_Prototype

This is the new AMTAIR project software implementation prototype (v.0.1) from March 2025.
https://docs.google.com/document/d/1QKu_7O1Tt30ohaikDDKGFLL-kv2IogmJ9fO2H0jigqI/edit?tab=t.0

